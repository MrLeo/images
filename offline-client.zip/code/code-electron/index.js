const { app, BrowserWindow } = require('electron')

let win
app.addListener('ready', () => {
  win = new BrowserWindow({ width: 1000, height: 725 })
  win.loadURL('https://baidu.com')

  win.webContents.executeJavaScript(`
    var button = document.createElement('button')
    button.innerText = '这是我的按钮'
    button.style = "width: 100px; height: 30px; background-color: red;"
    button.onclick = () => {
      alert(document.querySelector('#kw').value)
    }
    document.body.appendChild(button)
  `)
})
