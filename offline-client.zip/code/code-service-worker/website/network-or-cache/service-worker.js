const CACHE_KEY = 'network-or-cache'

self.addEventListener('install', (event) => {
  console.log('service-worker installed')
})

self.addEventListener('fetch', (event) => {
  const urlObj = new URL(event.request.url)
  if (urlObj.hostname !== 'localhost') return
  event.respondWith(fromCacheOrNetwork(event.request))
})

function fromCacheOrNetwork (req) {
  return caches.open(CACHE_KEY).then(cache => {
    return cache.match(req).then(res => {
      if (res) return res
      return addToCache(req)
    })
  })
}

function addToCache(req) {
  return fetch(req).then(res => {
    const cacheRes = res.clone()
    caches.open(CACHE_KEY).then(cache => {
      cache.put(req, cacheRes)
    })
    return res
  })
}
