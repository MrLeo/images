window.addEventListener('load', () => {
  navigator.serviceWorker.register('./service-worker.js').then(registration => {
    console.log('message-two-way service worker registered successful')
  }).catch(err => {
    console.error('message-two-way service worker registered failure', err)
  })

  document.querySelector('#btnSend').addEventListener('click', () => {
    if (navigator.serviceWorker.controller) {
      const channel = new MessageChannel()
      channel.port1.onmessage = (event) => {
        console.log('page received message from service worker: ', event.data)
      }

      navigator.serviceWorker.controller.postMessage({ command: 'two-way-message', message: 'message to servcie worker' }, [channel.port2])
    }
  })


  document.querySelector('#btnBroadcast').addEventListener('click', () => {
    if (navigator.serviceWorker.controller) {
      navigator.serviceWorker.onmessage = (event) => {
        if (event.data.command === 'broadcast-to-client') {
          console.log('page received message from service worker: ', event.data)
        }
      }

      navigator.serviceWorker.controller.postMessage({ command: 'broadcast', message: 'message to servcie worker' })
    }
  })
})
