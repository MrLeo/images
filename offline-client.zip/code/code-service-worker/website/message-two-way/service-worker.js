self.addEventListener('install', () => {

})

self.addEventListener('message', (event) => {
  console.log('service worker received message from page: ', event.data)

  if (event.data.command === 'two-way-message') {
    event.ports[0].postMessage({ message: 'message from service worker' })
  }

  if (event.data.command === 'broadcast') {
    self.clients.matchAll().then(clients => {
      clients.forEach(client => {
        client.postMessage({
          command: 'broadcast-to-client',
          message: 'message from servcie worker'
        })
      })
    })
  }
})