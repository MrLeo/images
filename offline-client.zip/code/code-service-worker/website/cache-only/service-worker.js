const CACHE_KEY = 'cache-only'

self.addEventListener('install', (event) => {
  console.log('service-worker installed')
  event.waitUntil(preCache())
})

self.addEventListener('active', (event) => {
  console.log('service-worker actived')
})

function preCache () {
  return caches.open(CACHE_KEY).then(cache => {
    return cache.addAll([
      'cached.html'
    ])
  })
}

self.addEventListener('fetch', (event) => {
  if (event.request.url.indexOf('cached.html') !== -1)
    event.respondWith(fromCache(event.request))
})

function fromCache (request) {
  return caches.open(CACHE_KEY).then(cache => {
    return cache.match(request).then(res => {
      return res || Promise.reject('no-match')
    })
  })
}
