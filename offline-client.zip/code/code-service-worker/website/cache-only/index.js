window.addEventListener('load', () => {
  navigator.serviceWorker.register('./service-worker.js').then(res => {
    console.log('cache-only service worker registered successfully')
  }).catch(err => {
    console.error('cache-only service worker registered failure', err)
  })
})