window.addEventListener('load', () => {
  navigator.serviceWorker.register('./service-worker.js').then(registration => {
    console.log('one-way-message service worker registered successful')
  }).catch(err => {
    console.error('one-way-message service worker registered error')
  })
})

document.querySelector('#btnSend').addEventListener('click', (evt) => {
  if (navigator.serviceWorker.controller) {
    navigator.serviceWorker.controller.postMessage({
      type: 'one-way',
      message: 'sss'
    })
  }
})