self.addEventListener('install', () => {
  console.log('one-way-message service worker installed')
})

self.addEventListener('message', (evt) => {
  console.log(evt.data)
})