const CACHE_KEY = 'cache-update'

self.addEventListener('install', (event) => {
  console.log('service-worker installed')
  event.waitUntil(caches.open(CACHE_KEY).then(cache => {
    cache.addAll(['./cached.html'])
  }))
})

self.addEventListener('fetch', (event) => {
  const urlObj = new URL(event.request.url)
  if (urlObj.hostname !== 'localhost') return
  event.respondWith(fromCacheOrNetwork(event.request))
  event.waitUntil(update(event.request))
})

function fromCacheOrNetwork (req) {
  return caches.open(CACHE_KEY).then(cache => {
    return cache.match(req).then(res => {
      if (res) return res
      return addToCache(req)
    })
  })
}

function addToCache(req) {
  return fetch(req).then(res => {
    return caches.open(CACHE_KEY).then(cache => {
      return cache.put(req, res.clone()).then(() => {
        return res
      })
    })
  })
}

function update(request) {
  return addToCache(request)
}

