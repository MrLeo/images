window.addEventListener('load', () => {
  navigator.serviceWorker.register('./service-worker.js').then(res => {
    console.log('network-or-cache service worker registered successfully')
  }).catch(err => {
    console.error('network-or-cache service worker registered failure', err)
  })
})
