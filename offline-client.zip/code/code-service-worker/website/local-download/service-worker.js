self.addEventListener('install', () => {
  self.skipWaiting()
})

self.addEventListener('fetch', event => {
  if (event.request.url.indexOf('download-file') !== -1) {
    event.respondWith(event.request.formData().then(formdata => {
      const filename = formdata.get('filename')
      const filebody = formdata.get('filebody')
      const response = new Response(filebody)
      response.headers.append('Content-Disposition', 'attachment; filename="' + filename + '"')
      return response
    }))
  }
})
