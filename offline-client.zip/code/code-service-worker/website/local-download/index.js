window.addEventListener('load', () => {
  navigator.serviceWorker.register('./service-worker.js').then(registration => {
    //
  }).catch(err => {
    console.error('local-download service worker registered failure')
  })
})