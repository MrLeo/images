# RD5离线客户端

### 目录结构

```javascript
- code/ ----------------------------------示例代码
  - code-electron ------------------------electron示例代码
  - code-service-worker ------------------service worker示例代码
- diagram/ -------------------------------各种图
  - html-docs ----------------------------时序图导出的html
  - RD5-Client.mdj -----------------------时序图源文件(StarUML)
  - RD5-Client.bmpr ----------------------交互图源文件(Balsamiq Mockups 3)
- ppt&video/ -----------------------------PPT和视频
  - RD5-Client.pptx ----------------------PPT
  - RD5-Client_20180530.mp4 --------------分享视频(@尤海洋)
```

